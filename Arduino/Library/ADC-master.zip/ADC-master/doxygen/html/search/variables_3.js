var searchData=
[
  ['diff_5ftable_5fadc0',['diff_table_ADC0',['../class_a_d_c.html#a3ac941166af84754393ce2e3006a1c16',1,'ADC']]],
  ['diff_5ftable_5fadc1',['diff_table_ADC1',['../class_a_d_c.html#ac75d6d8768a6def95664d8bb00ae502a',1,'ADC']]],
  ['dmachannel',['dmaChannel',['../class_ring_buffer_d_m_a.html#a289ca5377bb36f35f87127ce9719cbb7',1,'RingBufferDMA']]]
];
