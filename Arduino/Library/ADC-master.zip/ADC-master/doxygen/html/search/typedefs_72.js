var searchData=
[
  ['reg',['reg',['../class_a_d_c___module.html#a36fa42521ed88815b9085394c1fa7a92',1,'ADC_Module']]]
];
