var searchData=
[
  ['usedma',['useDMA',['../class_a_d_c.html#a9b32e609542d71601adb51b8383145c2',1,'ADC']]]
];
