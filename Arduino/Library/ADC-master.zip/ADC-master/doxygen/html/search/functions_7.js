var searchData=
[
  ['read',['read',['../class_ring_buffer.html#a8585065af57a71269bc46b30175c8dc8',1,'RingBuffer::read()'],['../class_ring_buffer_d_m_a.html#ac79ee944ee98c4da859c6e5f112022ea',1,'RingBufferDMA::read()']]],
  ['readsingle',['readSingle',['../class_a_d_c.html#aee7423bfcbb03465bb0bd1e3c6474452',1,'ADC::readSingle()'],['../class_a_d_c___module.html#a01d8bbca381dccfda87b7f6d27487340',1,'ADC_Module::readSingle()']]],
  ['readsynchronizedcontinuous',['readSynchronizedContinuous',['../class_a_d_c.html#acd10f3bc117a244e70e53c3489aa97bc',1,'ADC']]],
  ['readsynchronizedsingle',['readSynchronizedSingle',['../class_a_d_c.html#a38d941542bbdbc20c1b9e26a5051094a',1,'ADC']]],
  ['recalibrate',['recalibrate',['../class_a_d_c___module.html#afe8ed6f2a6c811ec3ef2c4aba768982f',1,'ADC_Module']]],
  ['ringbuffer',['RingBuffer',['../class_ring_buffer.html#a93b9973de32a836bdf70befaf9d78eed',1,'RingBuffer']]],
  ['ringbufferdma',['RingBufferDMA',['../class_ring_buffer_d_m_a.html#a37b578fe20ec7e7a361a614f9e9a2a07',1,'RingBufferDMA']]]
];
