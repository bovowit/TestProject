var searchData=
[
  ['adc',['ADC',['../class_a_d_c.html',1,'ADC'],['../class_a_d_c.html#a60b6e21403b1f30984f63832c0562960',1,'ADC::ADC()']]],
  ['adc0',['adc0',['../class_a_d_c.html#ab8deee5fdd0fec290faa1f01c1d4b7d7',1,'ADC']]],
  ['adc1',['adc1',['../class_a_d_c.html#a68fcbf0e8171f0b77b13a24161712c36',1,'ADC']]],
  ['adc_5fconfig',['ADC_Config',['../struct_a_d_c___module_1_1_a_d_c___config.html',1,'ADC_Module']]],
  ['adc_5fmodule',['ADC_Module',['../class_a_d_c___module.html',1,'ADC_Module'],['../class_a_d_c___module.html#a00b68ad621e3791747c061ce342d533f',1,'ADC_Module::ADC_Module()']]],
  ['adc_5fnum',['ADC_num',['../class_a_d_c___module.html#ac821322a022652d2a33cc29a8a7ba4aa',1,'ADC_Module']]],
  ['adc_5fnumber',['ADC_number',['../class_ring_buffer_d_m_a.html#a293d8fa003796812801612f64c1d7aa6',1,'RingBufferDMA']]],
  ['adcwasinuse',['adcWasInUse',['../class_a_d_c___module.html#a34f6f7878889aa3644b279f9440dc0bf',1,'ADC_Module']]],
  ['analogread',['analogRead',['../class_a_d_c.html#aaf6079870b115d8b029d3613d44091dd',1,'ADC::analogRead()'],['../class_a_d_c___module.html#ad492adad4a9fa728625be82602bf1672',1,'ADC_Module::analogRead()']]],
  ['analogreadcontinuous',['analogReadContinuous',['../class_a_d_c.html#a749efc928425a1eea18341ccfafd1819',1,'ADC::analogReadContinuous()'],['../class_a_d_c___module.html#ae3315625f0e0e87ddcf15d6493acb2f4',1,'ADC_Module::analogReadContinuous()']]],
  ['analogreaddifferential',['analogReadDifferential',['../class_a_d_c.html#aec3464cdb697f89cf162813b00b2e965',1,'ADC::analogReadDifferential()'],['../class_a_d_c___module.html#a4a57f6a9b0e3884f3862062b33f1a447',1,'ADC_Module::analogReadDifferential()']]],
  ['analogsynchronizedread',['analogSynchronizedRead',['../class_a_d_c.html#ac8067db45057f691e664f414d1376d1e',1,'ADC']]],
  ['analogsynchronizedreaddifferential',['analogSynchronizedReadDifferential',['../class_a_d_c.html#a156bb3fe55e8155dc42fd7e9df1eaa55',1,'ADC']]],
  ['adc',['ADC',['../md__c_1__users__user__arduino_libraries__a_d_c__r_e_a_d_m_e.html',1,'']]]
];
