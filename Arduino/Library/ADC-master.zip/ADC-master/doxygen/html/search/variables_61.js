var searchData=
[
  ['adc0',['adc0',['../class_a_d_c.html#ab8deee5fdd0fec290faa1f01c1d4b7d7',1,'ADC']]],
  ['adc1',['adc1',['../class_a_d_c.html#a68fcbf0e8171f0b77b13a24161712c36',1,'ADC']]],
  ['adc_5fnum',['ADC_num',['../class_a_d_c___module.html#ac821322a022652d2a33cc29a8a7ba4aa',1,'ADC_Module']]],
  ['adc_5fnumber',['ADC_number',['../class_ring_buffer_d_m_a.html#a293d8fa003796812801612f64c1d7aa6',1,'RingBufferDMA']]],
  ['adcwasinuse',['adcWasInUse',['../class_a_d_c___module.html#a34f6f7878889aa3644b279f9440dc0bf',1,'ADC_Module']]]
];
