var searchData=
[
  ['external',['EXTERNAL',['../_a_d_c_8h.html#af3fe37c1cda80aa7202b5a3bb7557dc9',1,'ADC.h']]]
];
