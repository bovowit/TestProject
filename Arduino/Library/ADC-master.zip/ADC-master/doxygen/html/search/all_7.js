var searchData=
[
  ['iscomplete',['isComplete',['../class_a_d_c.html#a5c508c2333310a834ca2f7cf59079807',1,'ADC::isComplete()'],['../class_a_d_c___module.html#a0648dd1435bfee45f9dc17908416c988',1,'ADC_Module::isComplete()']]],
  ['iscontinuous',['isContinuous',['../class_a_d_c.html#a4bf6474dd2ec0b75269e8fdb268f2c03',1,'ADC::isContinuous()'],['../class_a_d_c___module.html#a54bcee43fe87ee419f28549e255e9e8b',1,'ADC_Module::isContinuous()']]],
  ['isconverting',['isConverting',['../class_a_d_c.html#a564c5be3181c2b4ccca3fefc484832cb',1,'ADC::isConverting()'],['../class_a_d_c___module.html#aa8bf2a6ed42a69a53f7c27eaf0a49470',1,'ADC_Module::isConverting()']]],
  ['isdifferential',['isDifferential',['../class_a_d_c.html#a1bd89979194f6c9b0aa08463373aaa15',1,'ADC::isDifferential()'],['../class_a_d_c___module.html#aa0069ff00c919d00d9769b06dd3cb206',1,'ADC_Module::isDifferential()']]],
  ['isempty',['isEmpty',['../class_ring_buffer.html#a041d2e0a3ec68f91ea9847e220ed2501',1,'RingBuffer::isEmpty()'],['../class_ring_buffer_d_m_a.html#a0c10d34a151d2b9960e2ae58084e5baa',1,'RingBufferDMA::isEmpty()']]],
  ['isfull',['isFull',['../class_ring_buffer.html#a47f4fd274ccf142f55092ed851640201',1,'RingBuffer::isFull()'],['../class_ring_buffer_d_m_a.html#a52f974a38148e4baab0acbd2edb5c0e0',1,'RingBufferDMA::isFull()']]],
  ['ispgaenabled',['isPGAEnabled',['../class_a_d_c___module.html#ab512734714c0c3273ceebe8c1b96c5a3',1,'ADC_Module']]]
];
