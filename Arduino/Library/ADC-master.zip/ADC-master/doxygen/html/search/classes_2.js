var searchData=
[
  ['sync_5fresult',['Sync_result',['../struct_a_d_c_1_1_sync__result.html',1,'ADC']]]
];
