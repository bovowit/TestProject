var searchData=
[
  ['channel2sc1aadc0',['channel2sc1aADC0',['../class_a_d_c.html#a7d9a0a2e047047c5148b8b4ed13736de',1,'ADC']]],
  ['channel2sc1aadc1',['channel2sc1aADC1',['../class_a_d_c.html#a771218b6e00b24c3eee1446e6e480d9f',1,'ADC']]]
];
