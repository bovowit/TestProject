var searchData=
[
  ['disablecompare',['disableCompare',['../class_a_d_c.html#a3f511deae378e46a4a9ec80af90bf723',1,'ADC::disableCompare()'],['../class_a_d_c___module.html#ac635f675a9690a4db016c73c31818262',1,'ADC_Module::disableCompare()']]],
  ['disabledma',['disableDMA',['../class_a_d_c.html#ac53578061bc8bbbd1652b718c6032d07',1,'ADC::disableDMA()'],['../class_a_d_c___module.html#ac1610dcab46476f287c2dd4d96465c47',1,'ADC_Module::disableDMA()']]],
  ['disableinterrupts',['disableInterrupts',['../class_a_d_c.html#a269ea8bf6891c3095eea3b9d6decce67',1,'ADC::disableInterrupts()'],['../class_a_d_c___module.html#aa4509062644982526fee3c02e0b528fc',1,'ADC_Module::disableInterrupts()']]],
  ['disablepga',['disablePGA',['../class_a_d_c.html#ab9cb3e1c0ee39b45b4b84630606d85e1',1,'ADC::disablePGA()'],['../class_a_d_c___module.html#a734ac9cf07a54e91707c78d753d3d3dd',1,'ADC_Module::disablePGA()']]],
  ['dmachannel',['dmaChannel',['../class_ring_buffer_d_m_a.html#a289ca5377bb36f35f87127ce9719cbb7',1,'RingBufferDMA']]]
];
