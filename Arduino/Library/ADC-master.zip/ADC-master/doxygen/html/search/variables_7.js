var searchData=
[
  ['sc1a2channeladc0',['sc1a2channelADC0',['../class_a_d_c.html#ac83f0521b05578ac1faf0966a3128f33',1,'ADC']]],
  ['sc1a2channeladc1',['sc1a2channelADC1',['../class_a_d_c.html#a8769995229f5dc1f8dc4191eb97f9e09',1,'ADC']]]
];
