var _ring_buffer_d_m_a_8h =
[
    [ "RingBufferDMA", "class_ring_buffer_d_m_a.html", "class_ring_buffer_d_m_a" ],
    [ "DMA_BUFFER_SIZE", "_ring_buffer_d_m_a_8h.html#ac58748de79395a1751fc333bbc7ebd6b", null ]
];