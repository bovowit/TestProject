var _ring_buffer_8h =
[
    [ "RingBuffer", "class_ring_buffer.html", "class_ring_buffer" ],
    [ "RING_BUFFER_DEFAULT_BUFFER_SIZE", "_ring_buffer_8h.html#a231c232364ab25ef40c9a718b277074f", null ]
];