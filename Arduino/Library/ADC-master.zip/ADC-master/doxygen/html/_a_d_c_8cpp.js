var _a_d_c_8cpp =
[
    [ "dma_isr_0", "_a_d_c_8cpp.html#a66fa493056595dc39285952e112212e7", null ],
    [ "dma_isr_1", "_a_d_c_8cpp.html#a153f4b5f45e012008581c1c34657e2e7", null ]
];